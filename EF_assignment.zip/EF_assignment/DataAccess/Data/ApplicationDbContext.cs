﻿using CodingWiki_Model.Models;
using DataModels.Models;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Data
{
    public class ApplicationDbContext : DbContext
    {
        public DbSet<Book> Books { get; set; }
        //public DbSet<Genere> Generes { get; set; }
        public DbSet<BookDetail> BookDetails{ get; set; }
        public DbSet<Author> Authors { get; set; }
        public DbSet<BookAuthorMap> BookAuthorMaps { get; set; }
        public DbSet<Publisher> Publishers { get; set; }
      


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(
                "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=DB;Integrated Security=True;Connect Timeout=30;Encrypt=False;");
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //modelBuilder.Entity<Book>().Property(u => u.Price).HasPrecision(10, 5);

            //modelBuilder.Entity<Book>().HasData(new Book { BookId = 1 ,Title="Spiderman",ISBN="123456",Price=12.3}); 
            //modelBuilder.Entity<Book>().HasData(new Book { BookId = 2 ,Title="Superman",ISBN="333333",Price=22.3});
            
            //var booklist = new Book[] {
            //     new Book { BookId = 3 ,Title="Spiderman",ISBN="123456",Price=12.3},
            //     new Book { BookId = 4, Title = "Superman", ISBN = "333333", Price = 22.3 }
            //};

            //modelBuilder.Entity<Book>().HasData(booklist);
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Author>().HasKey(x => x.Author_Id);
            modelBuilder.Entity<Author>().Property(x => x.FirstName).IsRequired().HasMaxLength(50);
            modelBuilder.Entity<Author>().Property(x => x.LastName).IsRequired();

            modelBuilder.Entity<Book>().HasKey(x => x.BookId);
            modelBuilder.Entity<Book>().Property(x => x.ISBN).IsRequired().HasMaxLength(20);
            modelBuilder.Entity<Book>().HasOne(x => x.Publisher).WithMany(x=>x.Books).HasForeignKey(x=>x.BookId);

            modelBuilder.Entity<BookDetail>().HasKey(x => x.BookDetail_Id);
            modelBuilder.Entity<BookDetail>().HasOne(x => x.Book).WithOne(x => x.BookDetail).HasForeignKey<BookDetail>(x => x.BookId);

            modelBuilder.Entity<Publisher>().HasKey(x => x.Publisher_Id);
            modelBuilder.Entity<Publisher>().Property(x => x.Name).IsRequired();

            modelBuilder.Entity<BookAuthorMap>().HasKey(x => new { x.Book_Id, x.Author_Id });
            modelBuilder.Entity<BookAuthorMap>().HasOne(x => x.Book).WithMany(x => x.BookAuthorMap).HasForeignKey(x => x.Book_Id);
            modelBuilder.Entity<BookAuthorMap>().HasOne(x => x.Author).WithMany(x => x.BookAuthorMap).HasForeignKey(x => x.Author_Id);

        }
    }
}
