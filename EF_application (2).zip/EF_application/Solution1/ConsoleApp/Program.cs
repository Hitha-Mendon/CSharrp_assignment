﻿using Microsoft.EntityFrameworkCore;
using MilitaryApp.Data;
using MilitaryApp.ReverseEnggData;
using DomainHorse = MilitaryApp.Domain.Horse;
using DomainKing = MilitaryApp.Domain.King;
using DomainMilitary = MilitaryApp.Domain.Military;
using DomainQuote = MilitaryApp.Domain.Quote;

class Program
{
    static MilitaryContext context = new MilitaryContext();
    static void Main(string[] args)
    {
        
        context.Database.EnsureCreated();
        GetMilitary("Before Add: ");
        AddMilitary();
        InsertMulitipleMilitary();
        InsertVariousType();
        GetMilitary("After Add: ");
        GetAllMilitaries();
        GetMilitaryByName();
        GetMilitaryQuerySyntax();
        GetMilitaryWithParameter();
        GetMilitaryUsingLike();
        Queries();
        UpdateMilitary();
        DeleteMilitary();
        InsertNewMilitaryWithQuote();
        AddQuoteToExistingMilitary();
        EagerLoadMilitaryWithQuotes();
        FilteringWithRelatedData();
        QuerySQLView();
        QueryUsingRawSql();
        QueryUsingRawSqlWithInterpolation();
        QueryUsingFromRawSqlProcedure();
        InterpolatedRawSqlQueryStoredProc();
        ExecuteSomeRawSql();
    }

    private static void GetMilitary(string text)
    {
        var militaries = context.Militaries.ToList();
        Console.WriteLine($"{text}: Military Count is {militaries.Count}");
        foreach (var military in militaries)
        {
            Console.WriteLine(military.Name);
        }
    }

    private static void AddMilitary()
    {
        var military = new DomainMilitary
        {
            Name = "Amit",
            King = new DomainKing { KingName = "Shivaji" },
            Horse = new DomainHorse { Name = "Chetak" }
        };
        context.Militaries.Add(military);
        context.SaveChanges();
    }

    private static void InsertMulitipleMilitary()
    {
        var military1 = new DomainMilitary { Name = "Military 1" };
        var military2 = new DomainMilitary { Name = "Military 2" };
        var military3 = new DomainMilitary { Name = "Military 3" };
        var military4 = new DomainMilitary { Name = "Military 4" };
        context.Militaries.AddRange(military1, military2, military3, military4);
        context.SaveChanges();
    }

    private static void InsertVariousType()
    {
        var military = new DomainMilitary { Name = "Military 5 with king 1" };
        var king = new DomainKing { KingName = "King1" };
        context.AddRange(military, king);
        context.SaveChanges();
    }

    private static void GetAllMilitaries()
    {
        var militaries = context.Militaries.ToList();
        militaries.ForEach(m => Console.WriteLine(m.Name));
    }

    private static void GetMilitaryByName()
    {
        var militaries = context.Militaries
            .Where(m => m.Name == "Amit")
            .ToList();
    }

    private static void GetMilitaryQuerySyntax()
    {
        var militaries =
            (from m in context.Militaries
             where m.Name == "Amit"
             select m).ToList();
    }

    private static void GetMilitaryWithParameter()
    {
        string name = "Amit";
        var militaries = context.Militaries
            .Where(m => m.Name == name)
            .ToList();
    }

    private static void GetMilitaryUsingLike()
    {
        var militaries = context.Militaries
            .Where(m => EF.Functions.Like(m.Name, "Am%"))
            .ToList();
    }

    private static void Queries()
    {
        var m1 = context.Militaries.FirstOrDefault(m => m.Name == "Amit");
        var m2 = context.Militaries.FirstOrDefault(m => m.Name == "Amit");
        var m3 = context.Militaries.Find(2);
        var m4 = context.Militaries.OrderBy(m => m.Id).LastOrDefault(m => m.Name == "Amit");

        var militaries = context.Militaries.Skip(0).Take(3).ToList();
        militaries.ForEach(m => m.Name += " update ");
        context.SaveChanges();
    }

    private static void UpdateMilitary()
    {
        var military = context.Militaries.FirstOrDefault();
        if (military != null)
        {
            military.Name += "Name";
            context.SaveChanges();
        }
    }

    private static void DeleteMilitary()
    {
        var military = context.Militaries.FirstOrDefault();
        if (military != null)
        {
            context.Militaries.Remove(military);
            context.SaveChanges();
        }
    }

    private static void InsertNewMilitaryWithQuote()
    {
        var military = new DomainMilitary
        {
            Name = "Marathas",
            Quotes = new List<DomainQuote> { new DomainQuote { Text = "To save country" } }
        };
        context.Militaries.Add(military);
        context.SaveChanges();
    }

    private static void AddQuoteToExistingMilitary()
    {
        var military = context.Militaries.FirstOrDefault(); 
        if (military == null) return;

        var quote = new DomainQuote
        {
            Text = "To save nation",
            MilitaryId = military.Id 
        };
        using (var newContext = new MilitaryContext())
        {
            newContext.Quotes.Add(quote);
            newContext.SaveChanges();
        }
    }

    private static void EagerLoadMilitaryWithQuotes()
    {
        var militaryQuotes = context.Militaries.Include(s => s.Quotes).ToList();
        var militaryQuotesLeftJoin = context.Militaries.Include(s => s.Quotes).Include(s => s.King).ToList();
    }

    private static void FilteringWithRelatedData()
    {
        var military = context.Militaries
            .Where(s => s.Quotes.Any(q => q.Text.Contains("Happy")))
            .ToList();
    }

    private static void QuerySQLView()
    {
        var military = context.viewMilitary.FirstOrDefault();
    }

    private static void QueryUsingRawSql()
    {
        var result = context.Militaries
    .Select(m => new
    {
        m.Name,
        KingName = m.King.KingName
    })
    .ToList();

    }

    private static void QueryUsingRawSqlWithInterpolation()
    {
        string name = "amit";
  
        var military = context.Militaries
    .FromSqlInterpolated($@"
        SELECT Id, Name, KingId
        FROM Militaries
        WHERE Name = {name}")
    .ToList();
    }

    private static void QueryUsingFromRawSqlProcedure()
    {
        string name = "amit";

        var military = context.Militaries
            .FromSqlInterpolated($@"
            EXEC dbo.uspGetMilitary {context.Militaries
                           .Where(m => m.Name == name)
                           .Select(m => m.Id)
                           .FirstOrDefault()}")
            .ToList();
    }

    private static void InterpolatedRawSqlQueryStoredProc()
    {
        string name = "amit";
       
        var id = context.Militaries
            .Where(m => m.Name == name)
            .Select(m => m.Id)
            .FirstOrDefault();

     
        var military = context.Militaries
            .FromSqlInterpolated($"EXEC dbo.uspGetMilitary {id}")
            .ToList();
    }

    private static void ExecuteSomeRawSql()
    {
        string name = "amit";
        context.Database.ExecuteSqlInterpolated($"EXEC dbo.DeleteMilitary {name}");
    }
}