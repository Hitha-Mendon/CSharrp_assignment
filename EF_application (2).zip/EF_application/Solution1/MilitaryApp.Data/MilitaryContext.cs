﻿//using Microsoft.EntityFrameworkCore;
//using Microsoft.Extensions.Logging;
//using MilitaryApp.Domain;
//using System;
//using System.Collections;
//using System.Collections.Generic;
//using System.Linq;
//using System.Net.NetworkInformation;
//using System.Text;
//using System.Threading.Tasks;
//using Microsoft.Extensions.Logging;

//namespace MilitaryApp.Data
//{
//    //internal class MilitaryContext
//    //{
//    //}

//    public class MilitaryContext : DbContext
//    {
//        public DbSet<Military> Militaries { get; set; }
//        public DbSet<Quote> Quotes { get; set; }
//        public DbSet<King> Kings { get; set; }
//        public DbSet<Battle> Battles { get; set; }
//        public DbSet<Horse> Horses { get; set; }

//        public ILoggerFactory? ConsoleLoggerFactory { get; private set; }

//        protected override void OnModelCreating(ModelBuilder modelBuilder)
//        {
//            modelBuilder.Entity<MilitaryBattle>().HasKey(m => new {
//                m.MilitaryId,
//                m.BattleId
//            });
//            modelBuilder.Entity<Horse>().ToTable("Horses");
//        }


//        //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
//        //{
//        //    optionsBuilder
//        //        .UseSqlServer("Data Source=(local)\\SQLExpress;Initial Catalog=MilitaryDB;Integrated Security=True")
//        //        .EnableSensitiveDataLogging()
//        //        .LogTo(Console.WriteLine, Microsoft.Extensions.Logging.LogLevel.Information);
//        //}



//        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
//        {
//            optionsBuilder.UseLoggerFactory(ConsoleLoggerFactory).EnableSensitiveDataLogging()
//            .UseSqlServer("Data Source=(local)\\SQLexpress;Initial  Catalog = MilitaryDB; Integrated Security = True; TrustServerCertificate = True;");
//        }

//        //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
//        //{
//        //    optionsBuilder
//        //    .UseSqlServer("Data Source=(local)\\SQLexpress;Initial Catalog = MilitaryDB; Integrated Security = True ; TrustServerCertificate=True;"); 
//        //}
//    }

//}

using Microsoft.EntityFrameworkCore;
using MilitaryApp.Domain;
using Microsoft.Extensions.Logging;

namespace MilitaryApp.Data
{
    public class MilitaryContext : DbContext
    {
        public DbSet<Military> Militaries { get; set; }
        public DbSet<Quote> Quotes { get; set; }
        public DbSet<King> Kings { get; set; }
        public DbSet<Battle> Battles { get; set; }
        public DbSet<Horse> Horses { get; set; }
        public DbSet<ViewMilitary> viewMilitary { get; set; }

        public static readonly ILoggerFactory ConsoleLoggerFactory =
            LoggerFactory.Create(builder =>
            {
                builder.AddConsole();
            });

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder
                .UseLoggerFactory(ConsoleLoggerFactory)
                .EnableSensitiveDataLogging()
                .UseSqlServer(
                    "Data Source=(local)\\SQLexpress;" +
                    "Initial Catalog=MilitaryDB;" +
                    "Integrated Security=True;" +
                    "TrustServerCertificate=True;");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
          
            modelBuilder.Entity<MilitaryBattle>()
                .HasKey(mb => new { mb.MilitaryId, mb.BattleId });

         
            modelBuilder.Entity<Military>()
                .HasOne(m => m.King)
                .WithOne()
                .HasForeignKey<Military>(m => m.KingId)
                .OnDelete(DeleteBehavior.SetNull);

            modelBuilder.Entity<Horse>()
                .HasOne(h => h.Military)
                .WithOne(m => m.Horse)
                .HasForeignKey<Horse>(h => h.MilitaryId)
                .OnDelete(DeleteBehavior.Cascade);

          
            modelBuilder.Entity<Horse>().ToTable("Horses");

           
            modelBuilder.Entity<ViewMilitary>()
                .HasNoKey()
                .ToView("getBattle");
        }
    }
}