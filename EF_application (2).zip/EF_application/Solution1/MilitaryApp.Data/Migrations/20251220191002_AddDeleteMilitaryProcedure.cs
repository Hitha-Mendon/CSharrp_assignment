﻿//using Microsoft.EntityFrameworkCore.Migrations;

//#nullable disable

//namespace MilitaryApp.Data.Migrations
//{
//    /// <inheritdoc />
//    public partial class AddDeleteMilitaryProcedure : Migration
//    {
//        /// <inheritdoc />
//        protected override void Up(MigrationBuilder migrationBuilder)
//        {

//        }

//        /// <inheritdoc />
//        protected override void Down(MigrationBuilder migrationBuilder)
//        {

//        }
//    }
//}
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MilitaryApp.Data.Migrations
{
    public partial class AddDeleteMilitaryProcedure : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
                CREATE OR ALTER PROCEDURE dbo.DeleteMilitary
                    @Name NVARCHAR(50)
                AS
                BEGIN
                    DELETE FROM Militaries
                    WHERE Name = @Name;
                END
            ");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("DROP PROCEDURE dbo.DeleteMilitary");
        }
    }
}