﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MilitaryApp.Data.Migrations
{

    public partial class modification_addSqlProcedure_v3 : Migration
    {
    
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(
            @"
            CREATE OR ALTER PROCEDURE dbo.uspGetMilitary
                @militaryId INT
            AS
            BEGIN
                SELECT Id, Name, KingId 
                FROM Militaries
                WHERE Id = @militaryId;
            END"
            );
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("DROP PROCEDURE dbo.uspGetMilitary");
        }
    }
}