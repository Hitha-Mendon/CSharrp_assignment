﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MilitaryApp.Data.Migrations
{
    public partial class modification_addSqlView_Func_v2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
           
            migrationBuilder.Sql(
            @"CREATE OR ALTER FUNCTION dbo.funJoinColumnInfo
            (
                @name NVARCHAR(50)
            )
            RETURNS NVARCHAR(100)
            AS
            BEGIN
                DECLARE @result NVARCHAR(100);
                SET @result = @name;
                RETURN @result;
            END"
            );

            migrationBuilder.Sql(
            @"CREATE OR ALTER VIEW dbo.getBattle
            AS
            SELECT 
                m.Name AS Name,
                k.KingName AS KingName
            FROM Militaries m
            LEFT JOIN Kings k ON m.KingId = k.Id"
            );
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("DROP VIEW dbo.getBattle");
            migrationBuilder.Sql("DROP FUNCTION dbo.funJoinColumnInfo");
        }
    }
}