﻿//this code matches substrings

using System;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

class MultiThreadedFileSearch
{
    static async Task Main()
    {
       
        string filePath = "C:\\Users\\hitha\\Downloads\\MultiThreadedFileSearch\\MultiThreadedFileSearch\\sample.txt";

        if (string.IsNullOrWhiteSpace(filePath) || !File.Exists(filePath))
        {
            Console.WriteLine("Invalid file path.");
            return;
        }

        Console.Write("Enter search term: ");
        string searchTerm = Console.ReadLine() ?? "";

        if (string.IsNullOrEmpty(searchTerm))
        {
            Console.WriteLine("Search term cannot be empty.");
            return;
        }

        // Read all lines from file
        string[] lines = await File.ReadAllLinesAsync(filePath);

        // Split into 4 segments
        int totalLines = lines.Length;
        int segmentSize = (int)Math.Ceiling(totalLines / 4.0);

        var cts = new CancellationTokenSource();
        var token = cts.Token;

        Task[] tasks = new Task[4];
        bool found = false;
        object lockObj = new object();

        for (int i = 0; i < 4; i++)
        {
            int start = i * segmentSize;
            int end = Math.Min(start + segmentSize, totalLines);

            tasks[i] = Task.Run(() =>
            {
                for (int lineIndex = start; lineIndex < end; lineIndex++)
                {
                    if (token.IsCancellationRequested)
                        return; // Stop if cancellation requested

                    if (lines[lineIndex].Contains(searchTerm, StringComparison.OrdinalIgnoreCase))
                    {
                        lock (lockObj)
                        {
                            if (!found)
                            {
                                found = true;
                                Console.WriteLine($"Found '{searchTerm}' in line {lineIndex + 1}: {lines[lineIndex]}");
                                cts.Cancel(); // Cancel other threads
                            }
                        }
                        return; // Stop current thread
                    }
                }
            }, token);
        }

        try
        {
            await Task.WhenAll(tasks);
        }
        catch (OperationCanceledException)
        {
            // Expected when cancellation happens
        }

        if (!found)
        {
            Console.WriteLine($"'{searchTerm}' not found in file.");
        }
    }
}

//code for whole word matching (case-insensitive)

// using System;
// using System.IO;
// using System.Linq;
// using System.Text.RegularExpressions;
// using System.Threading;
// using System.Threading.Tasks;

// class MultiThreadedFileSearch
// {
//     static async Task Main()
//     {
//         string filePath = "sample.txt";

//         if (string.IsNullOrWhiteSpace(filePath) || !File.Exists(filePath))
//         {
//             Console.WriteLine("Invalid file path.");
//             return;
//         }

//         Console.Write("Enter search term: ");
//         string searchTerm = Console.ReadLine() ?? "";

//         if (string.IsNullOrEmpty(searchTerm))
//         {
//             Console.WriteLine("Search term cannot be empty.");
//             return;
//         }

//         // Escape special regex characters in search term
//         string pattern = $@"\b{Regex.Escape(searchTerm)}\b";
//         var regex = new Regex(pattern, RegexOptions.IgnoreCase);

//         string[] lines = await File.ReadAllLinesAsync(filePath);

//         int totalLines = lines.Length;
//         int segmentSize = (int)Math.Ceiling(totalLines / 4.0);

//         var cts = new CancellationTokenSource();
//         var token = cts.Token;

//         Task[] tasks = new Task[4];
//         bool found = false;
//         object lockObj = new object();

//         for (int i = 0; i < 4; i++)
//         {
//             int start = i * segmentSize;
//             int end = Math.Min(start + segmentSize, totalLines);

//             tasks[i] = Task.Run(() =>
//             {
//                 for (int lineIndex = start; lineIndex < end; lineIndex++)
//                 {
//                     if (token.IsCancellationRequested)
//                         return;

//                     if (regex.IsMatch(lines[lineIndex]))
//                     {
//                         lock (lockObj)
//                         {
//                             if (!found)
//                             {
//                                 found = true;
//                                 Console.WriteLine($"Found '{searchTerm}' in line {lineIndex + 1}: {lines[lineIndex]}");
//                                 cts.Cancel();
//                             }
//                         }
//                         return;
//                     }
//                 }
//             }, token);
//         }

//         try
//         {
//             await Task.WhenAll(tasks);
//         }
//         catch (OperationCanceledException)
//         {
//             // Expected when cancellation happens
//         }

//         if (!found)
//         {
//             Console.WriteLine($"'{searchTerm}' not found in file.");
//         }
//     }
// }
