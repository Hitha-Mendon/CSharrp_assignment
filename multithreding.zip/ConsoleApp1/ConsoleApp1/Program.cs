﻿using System;
using System.Threading;
using System.Threading.Tasks;

class Program
{
    //Count Total Occurrences
    static async Task Main()
    {
        string filePath = "C:\\Users\\hitha\\Downloads\\ConsoleApp1\\ConsoleApp1\\sample.txt";

        if (string.IsNullOrWhiteSpace(filePath) || !File.Exists(filePath))
        {
            Console.WriteLine("Invalid file path.");
            return;
        }

        Console.Write("Enter search term: ");
        string searchTerm = Console.ReadLine() ?? "";

        if (string.IsNullOrEmpty(searchTerm))
        {
            Console.WriteLine("Search term cannot be empty.");
            return;
        }

        string[] lines = await File.ReadAllLinesAsync(filePath);

        int totalLines = lines.Length;
        int segmentSize = (int)Math.Ceiling(totalLines / 4.0);

        Task[] tasks = new Task[4];

        int totalCount = 0;
        object lockObj = new object();

        for (int i = 0; i < 4; i++)
        {
            int start = i * segmentSize;
            int end = Math.Min(start + segmentSize, totalLines);

            tasks[i] = Task.Run(() =>
            {
                int localCount = 0;

                for (int lineIndex = start; lineIndex < end; lineIndex++)
                {
                    int index = 0;


                    while ((index = lines[lineIndex]
                            .IndexOf(searchTerm, index, StringComparison.OrdinalIgnoreCase)) != -1)
                    {
                        localCount++;
                        index += searchTerm.Length;
                    }
                }


                lock (lockObj)
                {
                    totalCount += localCount;
                }
            });
        }

        await Task.WhenAll(tasks);

        Console.WriteLine($"Total occurrences of '{searchTerm}': {totalCount}");
    }





}

//    //Use Barrier

//using System;
//using System.IO;
//using System.Threading;
//using System.Threading.Tasks;

//class MultiThreadedFileSearch_Barrier
//{
//    static async Task Main()
//    {
//        string filePath = "C:\\Users\\hitha\\Downloads\\ConsoleApp1\\ConsoleApp1\\sample.txt";

//        if (!File.Exists(filePath))
//        {
//            Console.WriteLine("Invalid file path.");
//            return;
//        }

//        Console.Write("Enter search term: ");
//        string searchTerm = Console.ReadLine() ?? "";

//        if (string.IsNullOrEmpty(searchTerm))
//        {
//            Console.WriteLine("Search term cannot be empty.");
//            return;
//        }

//        string[] lines = await File.ReadAllLinesAsync(filePath);

//        int totalLines = lines.Length;
//        int segmentSize = (int)Math.Ceiling(totalLines / 4.0);

//        int totalCount = 0;
//        object lockObj = new object();

//        // ✅ Barrier for 4 threads
//        Barrier barrier = new Barrier(4, (b) =>
//        {
//            Console.WriteLine("\nAll threads finished searching.\n");
//        });

//        Task[] tasks = new Task[4];

//        for (int i = 0; i < 4; i++)
//        {
//            int start = i * segmentSize;
//            int end = Math.Min(start + segmentSize, totalLines);

//            int threadId = i;

//            tasks[i] = Task.Run(() =>
//            {
//                int localCount = 0;

//                Console.WriteLine($"Thread {threadId} started...");

//                for (int lineIndex = start; lineIndex < end; lineIndex++)
//                {
//                    int index = 0;

//                    while ((index = lines[lineIndex]
//                            .IndexOf(searchTerm, index, StringComparison.OrdinalIgnoreCase)) != -1)
//                    {
//                        localCount++;
//                        index += searchTerm.Length;
//                    }
//                }

//                lock (lockObj)
//                {
//                    totalCount += localCount;
//                }

//                Console.WriteLine($"Thread {threadId} waiting at barrier...");

//                // ✅ Wait for others
//                barrier.SignalAndWait();
//            });
//        }

//        await Task.WhenAll(tasks);

//        Console.WriteLine($"Total occurrences: {totalCount}");
//    }
//}

